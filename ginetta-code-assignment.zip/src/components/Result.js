import React, { Component } from 'react';

export class Result extends Component {
  constructor(props) {
    super(props);
    this.state = {
      image: '',
      username: '',
      isHovered: false
      //active: 0
    };
  }

  toggleHover = () => {
    this.setState({
      isHovered: !this.state.isHovered
    });
  };

  containerStyle = () => {
    return {
      display: 'flex',
      alignSelf: 'center',
      margin: 'auto',
      width: '25%',
      backgroundColor: this.state.isHovered ? 'white' : '#ff851b'
    };
  };

  //handle keyboard events
  // onKeyDown = event => {
  //   if (event.keyCode === 13) {
  //     console.log('enter');
  //   } else if (event.keyCode === 38 && this.state.active > 0) {
  //     this.setState(prevState => ({
  //       active: prevState.active - 1
  //     }));
  //   } else if (event.keyCode === 40 && this.state.active < 6) {
  //     this.setState(prevState => ({
  //       active: prevState.active + 1
  //     }));
  //   }
  //   console.log(this.state.active);
  // };

  render() {
    const { avatar_url, login } = this.props.result;
    const githubUrl = `https://www.github.com/${login}`;

    return (
      <div
        className="result"
        style={this.containerStyle()}
        onMouseEnter={this.toggleHover}
        onMouseLeave={this.toggleHover}
        //handleKeyboardStuff
        // onKeyDown={this.onKeyDown}
        // tabIndex={0}
      >
        <a
          href={githubUrl}
          style={{ display: 'flex', textDecoration: 'none', color: 'black' }}
        >
          <img src={avatar_url} alt="" style={imgStyle} />
          <p style={userStyle}>{login}</p>
        </a>
      </div>
    );
  }
}

const imgStyle = {
  maxWidth: '4rem',
  maxHeight: '4rem',
  borderRadius: '3px'
};

const userStyle = {
  marginLeft: '1rem',
  borderBottom: '1px solid white'
};

export default Result;
