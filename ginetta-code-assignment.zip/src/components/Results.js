import React, { Component } from 'react';
import { Result } from './Result';

export class Results extends Component {
  render() {
    return this.props.results.slice(0, 5).map((result, index) => {
      return <Result result={result} key={index} />;
    });
  }
}

export default Results;
