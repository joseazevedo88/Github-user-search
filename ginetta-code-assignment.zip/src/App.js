import React, { Component } from 'react';
import Results from './components/Results';
import axios from 'axios';

class App extends Component {
  state = {
    results: []
  };

  getUsers = inputString => {
    axios
      .get(
        `https://api.github.com/search/users?q=${inputString}&access_token=34ec62b4c9a1bfb4195d7e38bd0ef9cbddc7e5a4`
      )
      .then(res =>
        this.setState({
          results: res.data.items
        })
      );
  };

  onChange = async event => {
    console.log(event.target.value.length);
    if (event.target.value.length > 0) {
      await this.getUsers(event.target.value);
    } else if (event.target.value.length === 0) {
      this.setState({
        results: []
      });
    }
  };

  render() {
    return (
      <div style={appStyle}>
        <div style={searchContainerStyle}>
          <input
            style={userSearchStyle}
            type="text"
            placeholder="Search github users..."
            onChange={this.onChange}
          />
          <Results results={this.state.results} />
        </div>
        <div style={someContentStyle1}>SOME OTHER CONTENT HERE</div>
        <div style={someContentStyle2}>SOME OTHER CONTENT HERE</div>
      </div>
    );
  }
}

const appStyle = {
  fontFamily: 'Oswald',
  backgroundImage: 'linear-gradient(to bottom right, #ff851b, #ff4136)',
  height: '100vh',
  overflow: 'auto',
  position: 'relative'
};

const searchContainerStyle = {
  paddingTop: '3rem',
  position: 'absolute',
  zIndex: '1',
  width: '100%'
};

const userSearchStyle = {
  display: 'block',
  margin: 'auto',
  height: '2rem',
  fontSize: '1rem',
  width: '25%',
  borderRadius: '5px'
};

const someContentStyle1 = {
  width: '600px',
  height: '100px',
  margin: '12rem auto',
  backgroundColor: '#ffbe6f',
  position: 'absolute',
  left: '2rem'
};
const someContentStyle2 = {
  width: '600px',
  height: '100px',
  margin: '12rem auto',
  backgroundColor: '#ffbe6f',
  position: 'absolute',
  right: '2rem'
};

export default App;
